<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ __('Instalação — Runaris Ghost') }}</title>
    @php $langJson = json_decode(file_get_contents(base_path('lang/'.app()->getLocale().'.json')), true) ?? []; @endphp
    <script id="lang-json" type="application/json">@json($langJson)</script>
    <script>window.__=function(k){const t=JSON.parse(document.getElementById('lang-json').textContent);return t[k]||k;};</script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
    @vite(['resources/css/app.css'])
</head>
<body class="installer-page">

<div class="orb orb-1"></div>
<div class="orb orb-2"></div>

<div class="installer-wrap">
<main class="glass-card" role="main">

    <header class="text-center mb-4">
        <img src="{{ Vite::asset('resources/assets/images/ghost-icon-transparent.png') }}" alt="Runaris Ghost" class="ghost-icon mb-2">
        <span class="brand-logo d-block">Runaris <span class="opacity-50">Ghost</span></span>
        <p class="text-secondary small text-uppercase mb-0 ls-wide">{{ __('Web Installer') }}</p>
    </header>

    <!-- Progress Pips -->
    <div class="progress-bar-wrap" id="pips"></div>

    <!-- STEP 0: Requirements -->
    <div id="step-0" class="step active" aria-current="step">
        <div class="text-center mb-4">
            <i class="bi bi-cpu display-4 text-primary d-block mb-3" aria-hidden="true"></i>
            <h3 class="fw-bold">{{ __('Verificação do Servidor') }}</h3>
            <p class="text-secondary">{{ __('Verificando se o servidor atende aos requisitos mínimos.') }}</p>
        </div>
        <div id="req-list" class="mb-4" role="region" aria-live="polite"><div class="text-center py-4"><span class="spinner-border spinner-border-sm me-2" aria-hidden="true"></span>{{ __('Analisando...') }}</div></div>
        <div class="d-flex justify-content-end">
            <button class="btn btn-brand" id="btn-req-next" disabled onclick="goTo(1)">{{ __('Próximo') }} <i class="bi bi-arrow-right ms-1"></i></button>
        </div>
    </div>

    <!-- STEP 1: Language -->
    <div id="step-1" class="step">
        <div class="text-center mb-4">
            <i class="bi bi-translate display-4 text-primary d-block mb-3" aria-hidden="true"></i>
            <h3 class="fw-bold">{{ __('Idioma / Language') }}</h3>
            <p class="text-secondary">{{ __('Escolha o idioma da interface.') }}</p>
        </div>
        <div class="row g-3 justify-content-center mb-4">
            <div class="col-6 col-md-3"><button class="btn btn-outline-secondary w-100 p-3 rounded-4 border-opacity-10" onclick="pickLang('pt_BR')" aria-label="Português do Brasil"><span class="fs-2 d-block mb-1" aria-hidden="true">🇧🇷</span><span class="small fw-bold">Português (BR)</span></button></div>
            <div class="col-6 col-md-3"><button class="btn btn-outline-secondary w-100 p-3 rounded-4 border-opacity-10" onclick="pickLang('pt_PT')" aria-label="Português de Portugal"><span class="fs-2 d-block mb-1" aria-hidden="true">🇵🇹</span><span class="small fw-bold">Português (PT)</span></button></div>
            <div class="col-6 col-md-3"><button class="btn btn-outline-secondary w-100 p-3 rounded-4 border-opacity-10" onclick="pickLang('en')" aria-label="English"><span class="fs-2 d-block mb-1" aria-hidden="true">🇺🇸</span><span class="small fw-bold">English</span></button></div>
            <div class="col-6 col-md-3"><button class="btn btn-outline-secondary w-100 p-3 rounded-4 border-opacity-10" onclick="pickLang('es')" aria-label="Español"><span class="fs-2 d-block mb-1" aria-hidden="true">🇪🇸</span><span class="small fw-bold">Español</span></button></div>
        </div>
    </div>


    <!-- STEP 3: Database -->
    <div id="step-3" class="step">
        <div class="text-center mb-4">
            <i class="bi bi-database-fill-check display-4 text-info d-block mb-3" aria-hidden="true"></i>
            <h3 class="fw-bold">{{ __('Banco de Dados') }}</h3>
            <p class="text-secondary">{{ __('O Runaris Ghost utiliza SQLite para garantir portabilidade e performance.') }}</p>
        </div>
        
        <div class="p-4 rounded-4 bg-info bg-opacity-10 border border-info border-opacity-10 mb-4">
            <div class="d-flex align-items-start gap-3">
                <i class="bi bi-info-circle-fill text-info fs-4" aria-hidden="true"></i>
                <div>
                    <h6 class="fw-bold mb-1">{{ __('Por que SQLite?') }}</h6>
                    <p class="small text-secondary mb-0">{{ __('Diferente de bancos tradicionais, o SQLite é um arquivo dentro do seu projeto. Isso facilita backups, migrações e garante que o app funcione em qualquer hospedagem sem configurações extras.') }}</p>
                </div>
            </div>
        </div>

        <div id="db-msg" class="d-none alert-box mb-3" role="alert"></div>
        
        <div class="d-flex justify-content-between align-items-center">
            <button class="btn btn-link text-secondary text-decoration-none" onclick="goTo(1)"><i class="bi bi-arrow-left me-1"></i> {{ __('Voltar') }}</button>
            <div class="d-flex gap-2">
                <button class="btn btn-brand px-4" id="btn-db-save" onclick="configureDb()">
                    <i class="bi bi-gear-fill me-2"></i>{{ __('Inicializar Banco de Dados') }}
                </button>
            </div>
        </div>
    </div>

    <!-- STEP 4: Admin User -->
    <div id="step-4" class="step">
        <h3 class="fw-bold mb-2">{{ __('Perfil & Segurança') }}</h3>
        <p class="text-secondary mb-4">{{ __('Crie sua conta de administrador.') }}</p>
        <form id="admin-form">
            <div class="row g-3 mb-3">
                <div class="col-md-6"><label for="admin-name" class="form-label text-uppercase small fw-bold opacity-50">{{ __('Nome do Autor') }}</label><input id="admin-name" type="text" name="name" class="form-control" placeholder="{{ __('Ex: Machado de Assis') }}" required></div>
                <div class="col-md-6"><label for="admin-email" class="form-label text-uppercase small fw-bold opacity-50">{{ __('E-mail') }}</label><input id="admin-email" type="email" name="email" class="form-control" placeholder="{{ __('seu@email.com') }}" required></div>
            </div>
            <div class="mb-3">
                <div class="form-check form-switch fs-5 mb-3">
                    <input class="form-check-input" type="checkbox" id="use_pw" checked onchange="togglePw(this.checked)">
                    <label class="form-check-label fs-6 fw-bold">{{ __('Proteger com senha') }}</label>
                </div>
                <div id="pw-fields">
                    <div class="row g-3">
                        <div class="col-md-6"><label for="pw1" class="visually-hidden">{{ __('Senha') }}</label><input type="password" name="password" id="pw1" class="form-control" placeholder="{{ __('Senha (mín. 8 caracteres)') }}"></div>
                        <div class="col-md-6"><label for="pw2" class="visually-hidden">{{ __('Confirmar senha') }}</label><input type="password" name="password_confirmation" id="pw2" class="form-control" placeholder="{{ __('Confirmar senha') }}"></div>
                    </div>
                </div>
                <div id="pw-warn" class="password-warning d-none mt-3"><i class="bi bi-exclamation-triangle-fill me-2"></i><strong>{{ __('Atenção:') }}</strong> {{ __('Sem senha, qualquer pessoa com acesso ao servidor poderá editar seus manuscritos.') }}</div>
            </div>
            <div id="admin-msg" class="d-none alert-box mb-3" role="alert"></div>
            <div class="d-flex justify-content-between">
                <button type="button" class="btn btn-link text-secondary text-decoration-none" onclick="goTo(3)"><i class="bi bi-arrow-left me-1"></i> {{ __('Voltar') }}</button>
                <button type="submit" class="btn btn-brand" id="btn-admin">{{ __('Próximo') }} <i class="bi bi-arrow-right ms-1"></i></button>
            </div>
        </form>
    </div>

    <!-- STEP 5: AI -->
    <div id="step-5" class="step">
        <h3 class="fw-bold mb-2">{{ __('Inteligência Artificial') }} <span class="badge bg-secondary bg-opacity-25 fw-normal fs-6">{{ __('Opcional') }}</span></h3>
        <p class="text-secondary mb-4">{{ __('O Runaris Ghost usa o Google Gemini para oferecer sugestões de escrita e brainstorm de personagens.') }}</p>
        <div class="mb-4 p-4 rounded-4 bg-info bg-opacity-10 border border-info border-opacity-10">
            <label class="form-label text-uppercase small fw-bold opacity-50">Google Gemini API Key</label>
            <input type="password" id="ai_key" class="form-control mb-3" placeholder="AIzaSy...">
            <p class="small text-body-secondary mb-0"><i class="bi bi-info-circle"></i> {{ __('Obtenha sua chave gratuita no') }} <a href="https://aistudio.google.com/app/apikey" target="_blank" class="fw-bold text-info">Google AI Studio</a>.</p>
        </div>
        <div class="d-grid gap-2">
            <button class="btn btn-brand" onclick="saveAi()">{{ __('Ativar Inteligência Artificial') }}</button>
            <button class="btn btn-link text-secondary text-decoration-none" onclick="goTo(6)">{{ __('Pular — não quero usar IA agora') }}</button>
        </div>
    </div>

    <!-- STEP 6: Done -->
    <div id="step-6" class="step text-center">
        <i class="bi bi-check-circle-fill display-1 text-success d-block mb-4" aria-hidden="true"></i>
        <h2 class="fw-bold mb-3">{{ __('Instalação Concluída!') }}</h2>
        <p class="text-secondary mb-2">{{ __('Seu Santuário Digital está pronto. Todas as configurações foram salvas e o servidor está protegido.') }}</p>
        <p class="text-secondary small mb-4 opacity-50">{{ __('O arquivo .env foi travado (somente leitura). Para reconfigurar, use o Reset de Fábrica dentro do app.') }}</p>
        <button class="btn btn-brand btn-lg px-5" id="btn-finish" onclick="finalizeInstall()"><i class="bi bi-door-open me-2"></i>{{ __('Entrar no Ghost') }}</button>
    </div>

</main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const STEPS=6, csrf=document.querySelector('meta[name="csrf-token"]').content;
let current=0, selectedDb='sqlite', selectedLang='pt_BR';

function H(m){return{'Content-Type':'application/json','X-CSRF-TOKEN':csrf,'Accept':'application/json'}}

// --- Navigation ---
function goTo(s){
    document.querySelectorAll('.step').forEach(el=>{el.classList.remove('active');el.removeAttribute('aria-current');});
    const next=document.getElementById('step-'+s);
    next.classList.add('active');
    next.setAttribute('aria-current','step');
    current=s;
    renderPips();
}
function renderPips(){
    const el=document.getElementById('pips');
    el.setAttribute('role','progressbar');
    el.setAttribute('aria-valuenow',current);
    el.setAttribute('aria-valuemin','0');
    el.setAttribute('aria-valuemax',STEPS);
    el.setAttribute('aria-label','Progresso da instalação');
    el.innerHTML='';
    for(let i=0;i<STEPS;i++){
        const d=document.createElement('div');
        d.className='pip'+(i<current?' done':'')+(i===current?' active':'');
        d.setAttribute('aria-current',i===current?'step':'false');
        el.appendChild(d);
    }
}
renderPips();

// --- Step 0: Requirements ---
async function checkReqs(){
    try{
        const r=await fetch('/install/requirements');
        const d=await r.json();
        let html='';
        // PHP
        const p=d.php_version;
        html+=`<div class="req-item"><i class="bi bi-${p.ok?'check-circle-fill req-ok':'x-circle-fill req-fail'}"></i><span>${p.label}</span><span class="ms-auto text-secondary small">${p.current}</span></div>`;
        // Extensions
        d.extensions.forEach(e=>{
            html+=`<div class="req-item"><i class="bi bi-${e.ok?'check-circle-fill req-ok':'x-circle-fill req-fail'}"></i><span>ext-${e.name}</span></div>`;
        });
        // Optional
        d.optional.forEach(e=>{
            html+=`<div class="req-item"><i class="bi bi-${e.ok?'check-circle-fill req-ok':'dash-circle req-warn'}"></i><span>ext-${e.name} <small class="text-secondary">(opcional)</small></span></div>`;
        });
        // Permissions
        d.permissions.forEach(p=>{
            html+=`<div class="req-item"><i class="bi bi-${p.ok?'check-circle-fill req-ok':'x-circle-fill req-fail'}"></i><span>${p.path} <small class="text-secondary">${p.ok?'writable':window.__('sem permissão')}</small></span></div>`;
        });
        // .env
        const ev=d.env_writable;
        html+=`<div class="req-item"><i class="bi bi-${ev.ok?'check-circle-fill req-ok':'x-circle-fill req-fail'}"></i><span>.env ${ev.exists?'':'('+window.__('será criado')+')'}</span></div>`;

        document.getElementById('req-list').innerHTML=html;
        document.getElementById('btn-req-next').disabled=!d.can_proceed;
    }catch(e){
        document.getElementById('req-list').innerHTML='<div class="alert-box err">'+window.__('Erro ao verificar requisitos.')+'</div>';
    }
}
checkReqs();

// --- Step 1: Language ---
function pickLang(l){selectedLang=l;goTo(3);}


// --- Step 3: Database ---
async function configureDb(){
    const msg=document.getElementById('db-msg');
    const btn=document.getElementById('btn-db-save');
    btn.disabled=true;btn.innerHTML='<span class="spinner-border spinner-border-sm me-2"></span>'+window.__('Inicializando Banco...');
    msg.className='d-none';
    try{
        const r=await fetch('/install/database/configure',{method:'POST',headers:H(),body:JSON.stringify({driver:'sqlite'})});
        const d=await r.json();
        if(d.status){goTo(4);}
        else{msg.className='alert-box err';msg.textContent=d.message;}
    }catch(e){msg.className='alert-box err';msg.textContent=window.__('Erro ao configurar banco.');}
    finally{btn.disabled=false;btn.innerHTML='<i class="bi bi-gear-fill me-2"></i>'+window.__('Inicializar Banco de Dados');}
}

// --- Step 4: Admin ---
function togglePw(on){
    document.getElementById('pw-fields').classList.toggle('d-none',!on);
    document.getElementById('pw-warn').classList.toggle('d-none',on);
    document.getElementById('pw1').required=on;
    document.getElementById('pw2').required=on;
}
document.getElementById('admin-form').onsubmit=async(e)=>{
    e.preventDefault();
    const msg=document.getElementById('admin-msg');
    const btn=document.getElementById('btn-admin');
    const fd=new FormData(e.target);
    const payload={name:fd.get('name'),email:fd.get('email'),password:fd.get('password'),password_confirmation:fd.get('password_confirmation'),use_password:document.getElementById('use_pw').checked?1:0};
    btn.disabled=true;btn.innerHTML='<span class="spinner-border spinner-border-sm me-2"></span>'+window.__('Criando...');
    msg.className='d-none';
    try{
        const r=await fetch('/install/admin',{method:'POST',headers:H(),body:JSON.stringify(payload)});
        const d=await r.json();
        if(r.ok&&d.status){goTo(5);}
        else{let m=d.message||window.__('Erro.');if(d.errors)m=Object.values(d.errors).flat().join('<br>');msg.className='alert-box err';msg.innerHTML=m;}
    }catch(er){msg.className='alert-box err';msg.textContent=window.__('Erro de conexão.');}
    finally{btn.disabled=false;btn.innerHTML=window.__('Próximo')+' <i class="bi bi-arrow-right ms-1"></i>';}
};

// --- Step 5: AI ---
async function saveAi(){
    const key=document.getElementById('ai_key').value;
    if(!key){goTo(6);return;}
    try{await fetch('/install/ai',{method:'POST',headers:H(),body:JSON.stringify({gemini_api_key:key})});}catch(e){}
    goTo(6);
}

// --- Step 6: Finalize ---
async function finalizeInstall(){
    const btn=document.getElementById('btn-finish');
    btn.disabled=true;btn.innerHTML='<span class="spinner-border spinner-border-sm me-2"></span>'+window.__('Finalizando...');
    try{await fetch('/install/finalize',{method:'POST',headers:H()});}catch(e){}
    window.location.href='/';
}
</script>
</body>
</html>
